export const GASOLINE_TOKEN = 'gasoline-token';
export const API_URL = 'http://gasoline-gallery:8080/api'